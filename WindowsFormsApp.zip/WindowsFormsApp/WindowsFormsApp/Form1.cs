﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {

        private int number;
        private List<int> divisors = new List<int>();
        private int numberToSearch;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            divisors = new List<int>();
            if (int.TryParse(textBox1.Text, out number))
            {
                for(int i = 30; i <= 160; i++)
                {
                    if (i % number == 0)
                        divisors.Add(i);
                }

                textBox2.Text = string.Join(";", divisors);
            }
            else
            {
                textBox2.Text = "Niepoprawna liczba";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out numberToSearch))
            {
                if (divisors.Any(x => x == numberToSearch))
                    textBox4.Text = "Tak! Liczba znajduje sie w tablicy!";
                else
                    textBox4.Text = "Nie! Liczba nie znajduje sie w tablicy!";
            }
            else
            {
                textBox4.Text = "Niepoprawna liczba";
            }
        }
    }
}
